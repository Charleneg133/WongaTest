using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ServicesUnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void PublishTest()
        {

        }
    }
}
