﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Receive
{
    public sealed class ReceiveConstants
    {
        
            public const string HOST_NAME = "HostName";
            public const string QUEUE_NAME = "QueueName";
            public const string VALIDATION_LIST = "ValidationList";

     }
}

