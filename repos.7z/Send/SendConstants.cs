﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Send
{
    public sealed class SendConstants
    {
        public const string HOST_NAME = "HostName";
        public const string QUEUE_NAME = "QueueName";
        
    }
}
